import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  return (
    <div className="max-w-xl mx-auto mt-10 p-6 border rounded shadow space-y-4">
      <h2 className="text-2xl font-semibold text-green-700 text-center">
        Welcome, {user?.username}!
      </h2>

      <div className="text-center space-y-1">
        <p><strong>Email:</strong> {user?.email}</p>
        <p><strong>Role:</strong> {user?.role}</p>
      </div>

      {/* Common: Edit Your Info */}
      <div className="flex justify-center gap-3">
        <button
          onClick={() => navigate(`/update/${user._id}`)}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Edit Your Info
        </button>

        <button
          onClick={logout}
          className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
        >
          Logout
        </button>
      </div>

      {/* Admin Controls */}
      {user?.role === "admin" && (
        <div className="mt-6 space-y-2">
          <h3 className="text-xl font-bold text-gray-800 text-center">Admin Controls</h3>
          <div className="flex flex-wrap justify-center gap-3">
            <button
              onClick={() => navigate("/admin/add")}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
            >
              Add User
            </button>
            <button
              onClick={() => navigate("/admin/users")}
              className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
            >
              Manage Users
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;