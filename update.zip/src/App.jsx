import React, { useContext } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Home from "./pages/Home";
import ProfilePage from "./pages/ProfilePage";
import AdminPage from "./pages/AdminPage";
import NotFound from "./pages/NotFound";
import AddUser from "./pages/Admin/AddUser";         // ✅ New Page
import ManageUsers from "./pages/Admin/ManageUsers"; // ✅ New Page
import { AuthContext } from "./context/AuthContext";

const App = () => {
  const { user } = useContext(AuthContext);

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/register" />} />
      <Route path="/register" element={<Register />} />
      <Route path="/login" element={<Login />} />

      {user ? (
        <>
          <Route path="/home" element={<Home />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/admin" element={<AdminPage />} />

          {/* ✅ Admin only routes */}
         {user.role === "admin" && (
  <>
    <Route path="/admin" element={<AdminPage />} />
    <Route path="/admin/add-user" element={<AddUser />} />
    <Route path="/admin/users" element={<ManageUsers />} />
  </>
)}
        </>
      ) : (
        <>
          {/* Redirect if unauthenticated */}
          <Route path="/home" element={<Navigate to="/login" />} />
          <Route path="/profile" element={<Navigate to="/login" />} />
          <Route path="/admin" element={<Navigate to="/login" />} />
          <Route path="/admin/add-user" element={<Navigate to="/login" />} />
          <Route path="/admin/users" element={<Navigate to="/login" />} />
        </>
      )}

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;